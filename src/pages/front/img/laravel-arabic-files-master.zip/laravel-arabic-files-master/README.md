# laravel-arabic-files
Arabic Translations/Config for Laravel 📿 🇸🇦


Included:

- ✅ default templates
- ✅ default email messages
- ✅ default error messages
- ✅ default validation error messages
- ✅ Voyager langauge files
- ✅ An implementation of multilingual timezones support
- ✅ An implementation of multilingual countries support


Feel free to PR new files/changes. 😘
